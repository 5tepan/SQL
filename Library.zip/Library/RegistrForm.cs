﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library
{
    public partial class RegistrForm : Form
    {
        public RegistrForm()
        {
            InitializeComponent();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        Point lastPoint;
        private void RegistrForm_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void RegistrForm_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            if (nameField.Text == "")
            {
                MessageBox.Show("Введите полное имя!");
                return;
            }

            if (loginRegister.Text == "")
            {
                MessageBox.Show("Введите логин!");
                return;
            }

            if (passwordRegister1.Text == "")
            {
                MessageBox.Show("Введите пароль!");
                return;
            }

            if (passwordRegister1.Text != passwordRegister2.Text)
            {
                MessageBox.Show("Пароли не совпадают!");
                return;
            }

            if (passwordRegister1.Text != "" && passwordRegister2.Text == "")
            {
                MessageBox.Show("Повторите пароль!");
                return;
            }

            if (passwordRegister1.Text == "" && passwordRegister2.Text != "")
            {
                MessageBox.Show("Введите пароль!");
                return;
            }

            if (isUserExist())
                return;

            DBconnect db = new DBconnect();
            SqlCommand command = new SqlCommand("INSERT INTO [user] ([full_name], [email], [password], [id_role]) VALUES (@name, @login, @pass, @id_r)", db.getConnection());
            
            command.Parameters.Add("@name", SqlDbType.VarChar).Value = nameField.Text;
            command.Parameters.Add("@login", SqlDbType.VarChar).Value = loginRegister.Text;
            command.Parameters.Add("@pass", SqlDbType.VarChar).Value = passwordRegister1.Text;
            command.Parameters.Add("@id_r", SqlDbType.Int).Value = 2;

            db.openConnection();

            if (command.ExecuteNonQuery() == 1)
            {
                this.Hide();
                MainForm mainForm = new MainForm();
                mainForm.Show();
            }    
                
            else
                MessageBox.Show("Registration error. Please try again later!");

            db.closeConnection();
        }

        public Boolean isUserExist()
        {
            DBconnect db = new DBconnect();

            DataTable table = new DataTable();

            SqlDataAdapter adapter = new SqlDataAdapter();

            int id_r = 1;
            int id_r1 = 2;

            SqlCommand command = new SqlCommand("SELECT * FROM [user] WHERE [email] = @uL", db.getConnection());
            command.Parameters.Add("@uL", SqlDbType.VarChar).Value = loginRegister.Text;

            adapter.SelectCommand = command;
            adapter.Fill(table);

            if (table.Rows.Count > 0)
            {
                MessageBox.Show("Пользователь уже существует!");
                return true;
            }
            else
                return false;
        }

        private void authorization_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
        }
    }
}
