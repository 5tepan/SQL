﻿
namespace Library
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.closeButton = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBook1 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.icon_user2 = new System.Windows.Forms.PictureBox();
            this.icon_favorite = new System.Windows.Forms.PictureBox();
            this.icon_recommended = new System.Windows.Forms.PictureBox();
            this.icon_library = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBook1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.icon_user2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.icon_favorite)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.icon_recommended)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.icon_library)).BeginInit();
            this.SuspendLayout();
            // 
            // closeButton
            // 
            this.closeButton.AutoSize = true;
            this.closeButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeButton.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.closeButton.Location = new System.Drawing.Point(1108, -1);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(20, 20);
            this.closeButton.TabIndex = 10;
            this.closeButton.Text = "X";
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBook1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 407);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1125, 531);
            this.panel1.TabIndex = 11;
            // 
            // pictureBook1
            // 
            this.pictureBook1.Location = new System.Drawing.Point(45, 115);
            this.pictureBook1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBook1.Name = "pictureBook1";
            this.pictureBook1.Size = new System.Drawing.Size(253, 281);
            this.pictureBook1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBook1.TabIndex = 15;
            this.pictureBook1.TabStop = false;
            // 
            // label5
            // 
            this.label5.Dock = System.Windows.Forms.DockStyle.Top;
            this.label5.Font = new System.Drawing.Font("Bauhaus 93", 40F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label5.Location = new System.Drawing.Point(0, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(1125, 86);
            this.label5.TabIndex = 14;
            this.label5.Text = "new!";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Bauhaus 93", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(94, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 58);
            this.label1.TabIndex = 13;
            this.label1.Text = "Library";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Bauhaus 93", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label2.Location = new System.Drawing.Point(294, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(277, 58);
            this.label2.TabIndex = 15;
            this.label2.Text = "recommended";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Bauhaus 93", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label3.Location = new System.Drawing.Point(593, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(195, 58);
            this.label3.TabIndex = 17;
            this.label3.Text = "favourite";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Bauhaus 93", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label4.Location = new System.Drawing.Point(857, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(195, 58);
            this.label4.TabIndex = 19;
            this.label4.Text = "account";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // icon_user2
            // 
            this.icon_user2.Image = global::Library.Properties.Resources.icon_user2;
            this.icon_user2.Location = new System.Drawing.Point(825, 96);
            this.icon_user2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.icon_user2.Name = "icon_user2";
            this.icon_user2.Size = new System.Drawing.Size(253, 281);
            this.icon_user2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.icon_user2.TabIndex = 18;
            this.icon_user2.TabStop = false;
            this.icon_user2.Click += new System.EventHandler(this.icon_user2_Click);
            // 
            // icon_favorite
            // 
            this.icon_favorite.Image = global::Library.Properties.Resources.icon_favorite;
            this.icon_favorite.Location = new System.Drawing.Point(565, 96);
            this.icon_favorite.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.icon_favorite.Name = "icon_favorite";
            this.icon_favorite.Size = new System.Drawing.Size(253, 281);
            this.icon_favorite.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.icon_favorite.TabIndex = 16;
            this.icon_favorite.TabStop = false;
            this.icon_favorite.Click += new System.EventHandler(this.icon_favorite_Click);
            // 
            // icon_recommended
            // 
            this.icon_recommended.Image = global::Library.Properties.Resources.icon_recommended;
            this.icon_recommended.Location = new System.Drawing.Point(305, 96);
            this.icon_recommended.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.icon_recommended.Name = "icon_recommended";
            this.icon_recommended.Size = new System.Drawing.Size(253, 281);
            this.icon_recommended.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.icon_recommended.TabIndex = 14;
            this.icon_recommended.TabStop = false;
            this.icon_recommended.Click += new System.EventHandler(this.icon_recommended_Click);
            // 
            // icon_library
            // 
            this.icon_library.Image = global::Library.Properties.Resources.icon_library;
            this.icon_library.Location = new System.Drawing.Point(45, 96);
            this.icon_library.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.icon_library.Name = "icon_library";
            this.icon_library.Size = new System.Drawing.Size(253, 281);
            this.icon_library.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.icon_library.TabIndex = 12;
            this.icon_library.TabStop = false;
            this.icon_library.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Yellow;
            this.ClientSize = new System.Drawing.Size(1125, 938);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.icon_user2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.icon_favorite);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.icon_recommended);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.icon_library);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.closeButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseMove);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBook1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.icon_user2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.icon_favorite)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.icon_recommended)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.icon_library)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label closeButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox icon_library;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox icon_recommended;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox icon_favorite;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox icon_user2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBook1;
    }
}