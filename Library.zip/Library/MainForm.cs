﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Library
{
    public partial class MainForm : Form
    {

        DBconnect dataBase = new DBconnect();

        public MainForm()
        {
            InitializeComponent();
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LibraryForm libraryForm = new LibraryForm();
            libraryForm.Show();
        }

        private void icon_recommended_Click(object sender, EventArgs e)
        {
            this.Hide();
            RecommendedForm recommendedForm = new RecommendedForm();
            recommendedForm.Show();
        }

        private void icon_favorite_Click(object sender, EventArgs e)
        {
            this.Hide();
            FavoritForm favoritForm = new FavoritForm();
            favoritForm.Show();
        }

        private void icon_user2_Click(object sender, EventArgs e)
        {
            this.Hide();
            AccountForm accountForm = new AccountForm();
            accountForm.Show();
        }

        Point lastPoint;
        private void MainForm_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void MainForm_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }
    }
}
